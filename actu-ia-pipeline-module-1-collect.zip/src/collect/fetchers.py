"""Récupérateurs RSS et APIs publiques pour les sources de collecte."""
from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

import feedparser
import requests

LOGGER = logging.getLogger(__name__)
USER_AGENT = "actu-ia-pipeline/1.0 (+https://github.com/)"

@dataclass(slots=True)
class Article:
    """Article uniforme transmis aux modules suivants."""
    title: str
    url: str
    source: str
    summary: str = ""
    published_at: str | None = None
    score: float = 0.0
    guid: str = ""
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convertit l'article en dictionnaire sérialisable JSON."""
        data = asdict(self)
        data["metadata"] = data["metadata"] or {}
        return data


def _date(entry: Any) -> str | None:
    """Extrait une date RSS en ISO 8601, sans échouer sur un flux incomplet."""
    parsed = entry.get("published_parsed") or entry.get("updated_parsed")
    if parsed:
        return datetime(*parsed[:6], tzinfo=timezone.utc).isoformat()
    return entry.get("published") or entry.get("updated")


def fetch_rss(url: str, source: str, limit: int = 15, session: requests.Session | None = None) -> list[Article]:
    """Récupère un flux RSS/Atom sans nécessiter de clé."""
    response = (session or requests).get(url, timeout=20, headers={"User-Agent": USER_AGENT})
    response.raise_for_status()
    parsed = feedparser.parse(response.content)
    articles: list[Article] = []
    for entry in parsed.entries[:limit]:
        title = str(entry.get("title", "")).strip()
        link = str(entry.get("link", "")).strip()
        if not title or not link:
            continue
        articles.append(Article(title, link, source, str(entry.get("summary", "")), _date(entry), guid=str(entry.get("id", link))))
    return articles


def fetch_hackernews(url: str, source: str = "Hacker News", limit: int = 15, min_score: int = 0, session: requests.Session | None = None) -> list[Article]:
    """Récupère les meilleures histoires Hacker News et leurs détails."""
    client = session or requests
    ids = client.get(url, timeout=20, headers={"User-Agent": USER_AGENT}).json()[:limit * 3]
    articles = []
    for story_id in ids:
        item = client.get(f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json", timeout=20, headers={"User-Agent": USER_AGENT}).json()
        if item and item.get("type") == "story" and item.get("score", 0) >= min_score and item.get("url"):
            articles.append(Article(item.get("title", ""), item["url"], source, f"Score HN: {item.get('score', 0)}", metadata={"hn_score": item.get("score", 0), "hn_id": story_id}, guid=str(story_id)))
        if len(articles) >= limit:
            break
    return articles


def fetch_producthunt(url: str, source: str = "Product Hunt", limit: int = 15, session: requests.Session | None = None) -> list[Article]:
    """Récupère Product Hunt via GraphQL si PRODUCT_HUNT_TOKEN est défini."""
    token = os.getenv("PRODUCT_HUNT_TOKEN", "").strip()
    if not token:
        LOGGER.warning("PRODUCT_HUNT_TOKEN absent : Product Hunt ignoré")
        return []
    query = "query { posts(first: 20, order: NEWEST) { edges { node { id name tagline url createdAt } } } }"
    response = (session or requests).post(url, json={"query": query}, headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "User-Agent": USER_AGENT}, timeout=20)
    response.raise_for_status()
    payload = response.json()
    return [Article(n["name"], n["url"], source, n.get("tagline", ""), n.get("createdAt"), guid=str(n["id"])) for e in payload.get("data", {}).get("posts", {}).get("edges", [])[:limit] if (n := e.get("node"))]


def fetch_arxiv(url: str, source: str = "arXiv", limit: int = 15, session: requests.Session | None = None) -> list[Article]:
    """Récupère les résultats arXiv via son flux Atom public."""
    return fetch_rss(url, source, limit, session)


def fetch_source(config: dict[str, Any], limit: int = 15, session: requests.Session | None = None) -> list[Article]:
    """Dispatch un récupérateur selon la configuration YAML."""
    kind = str(config.get("type", "rss")).lower()
    kwargs = {"limit": limit, "session": session}
    if kind == "rss": return fetch_rss(config["url"], config.get("name", "RSS"), **kwargs)
    if kind in {"hackernews", "hn"}: return fetch_hackernews(config["url"], config.get("name", "Hacker News"), min_score=int(config.get("min_score", 0)), **kwargs)
    if kind in {"producthunt", "product_hunt"}: return fetch_producthunt(config["url"], config.get("name", "Product Hunt"), **kwargs)
    if kind == "arxiv": return fetch_arxiv(config["url"], config.get("name", "arXiv"), **kwargs)
    raise ValueError(f"Type de source inconnu : {kind}")
