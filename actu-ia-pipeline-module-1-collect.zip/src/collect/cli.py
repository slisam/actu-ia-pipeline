"""CLI du module de collecte, avec mode simulation sans réseau."""
from __future__ import annotations
import argparse
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from src.common.config import charger_config, dossier_episode
from src.common.logging_setup import configurer_logging
from .deduplicator import deduplicate_articles
from .fetchers import Article, fetch_source
from .selector import select_articles

LOGGER = logging.getLogger(__name__)

def _args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Collecte les actualités IA")
    parser.add_argument("--dry-run", action="store_true", help="n'effectue aucun appel réseau")
    parser.add_argument("--limit", type=int, default=15, help="nombre maximal d'articles")
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--output", type=Path, default=None)
    return parser.parse_args()

def run(config: dict[str, Any], dry_run: bool = False, limit: int = 15, output_dir: Path | None = None) -> list[Article]:
    """Exécute la collecte et écrit collect.json dans un dossier d'épisode."""
    sources = config.get("collect", {}).get("sources", [])
    keywords = config.get("collect", {}).get("keywords", [])
    all_articles: list[Article] = []
    if dry_run:
        all_articles = [Article("Démo : actualité IA", "https://example.com/demo-ia", "dry-run", "Article de démonstration IA", datetime.now(timezone.utc).isoformat())]
    else:
        for source in sources:
            try:
                all_articles.extend(fetch_source(source, min(limit, int(config["collect"].get("max_articles_per_source", limit)))))
            except Exception as exc:
                LOGGER.warning("Source %s ignorée : %s", source.get("name", "?"), exc)
    articles = select_articles(deduplicate_articles(all_articles), keywords, limit)
    target = output_dir or dossier_episode(datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S"))
    target.mkdir(parents=True, exist_ok=True)
    (target / "collect.json").write_text(json.dumps([a.to_dict() for a in articles], ensure_ascii=False, indent=2), encoding="utf-8")
    LOGGER.info("%d article(s) écrit(s) dans %s", len(articles), target / "collect.json")
    return articles

def main() -> None:
    """Point d'entrée de la commande collect."""
    args = _args()
    logger = configurer_logging("collect")
    logger.debug("Démarrage de la collecte")
    run(charger_config(args.config), args.dry_run, max(1, args.limit), args.output)

if __name__ == "__main__":
    main()
