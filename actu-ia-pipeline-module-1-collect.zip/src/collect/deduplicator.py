"""Déduplication d'articles par URL, identifiant et similarité de titre."""
from __future__ import annotations
from typing import Iterable
from rapidfuzz.fuzz import ratio
from .fetchers import Article

def deduplicate_articles(articles: Iterable[Article], threshold: float = 88.0) -> list[Article]:
    """Conserve le premier article de chaque doublon évident."""
    result: list[Article] = []
    urls: set[str] = set()
    for article in articles:
        normalized_url = article.url.rstrip("/").lower()
        title = " ".join(article.title.lower().split())
        if normalized_url in urls or any(ratio(title, " ".join(old.title.lower().split())) >= threshold for old in result):
            continue
        urls.add(normalized_url)
        result.append(article)
    return result
