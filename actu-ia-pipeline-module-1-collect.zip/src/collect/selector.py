"""Classement des articles selon les mots-clés de config.yaml."""
from __future__ import annotations
import re
from .fetchers import Article

def score_article(article: Article, keywords: list[str]) -> float:
    """Calcule un score 0-100, avec un poids supérieur pour le titre."""
    text = f"{article.title} {article.summary}".lower()
    title = article.title.lower()
    hits = sum(1 for word in keywords if word.lower() in text)
    title_hits = sum(1 for word in keywords if word.lower() in title)
    return min(100.0, round((hits * 12.0) + (title_hits * 18.0), 2))

def select_articles(articles: list[Article], keywords: list[str], limit: int = 15, minimum_score: float = 0.0) -> list[Article]:
    """Score, filtre et trie les articles les plus pertinents."""
    selected = []
    for article in articles:
        article.score = score_article(article, keywords)
        if article.score >= minimum_score:
            selected.append(article)
    return sorted(selected, key=lambda a: (-a.score, a.published_at or ""))[:limit]
