"""Tests complets et sans réseau du module collect."""
from __future__ import annotations
import json
from pathlib import Path
from unittest.mock import Mock
import pytest
from src.collect.deduplicator import deduplicate_articles
from src.collect.fetchers import Article, fetch_arxiv, fetch_hackernews, fetch_rss, fetch_source
from src.collect.selector import score_article, select_articles
from src.collect.cli import run

RSS = b'''<?xml version="1.0"?><rss><channel><item><title>GPT lance un agent IA</title><link>https://example.com/a</link><description>LLM et innovation</description></item><item><title>Autre article</title><link>https://example.com/b</link></item></channel></rss>'''

def response(content=RSS):
    r=Mock(); r.content=content; r.raise_for_status=Mock(); return r

def test_fetch_rss_normalise_articles():
    s=Mock(); s.get.return_value=response()
    items=fetch_rss('https://rss.test', 'Test', 10, s)
    assert len(items)==2 and items[0].title.startswith('GPT') and items[0].source=='Test'
    s.get.assert_called_once()

def test_fetch_arxiv_reutilise_rss():
    s=Mock(); s.get.return_value=response()
    assert fetch_arxiv('https://arxiv.test', session=s)[0].source == 'arXiv'

def test_fetch_hackernews_filtre_score():
    s=Mock(); a=Mock(); a.json.return_value=[1,2]; b=Mock(); b.json.return_value={'type':'story','title':'low','url':'https://low','score':2}; c=Mock(); c.json.return_value={'type':'story','title':'high','url':'https://high','score':120}; s.get.side_effect=[a,b,c]
    items=fetch_hackernews('https://hn.test', min_score=100, session=s)
    assert [x.url for x in items] == ['https://high']

def test_fetch_source_dispatch():
    s=Mock(); s.get.return_value=response()
    assert fetch_source({'type':'rss','name':'X','url':'u'}, session=s)[0].source == 'X'
    with pytest.raises(ValueError): fetch_source({'type':'unknown','url':'u'})

def test_deduplicate_url_and_fuzzy_title():
    items=[Article('Nouveau modèle IA', 'https://x/','a'), Article('Nouveau modèle IA!', 'https://y','b'), Article('Autre', 'https://x','c')]
    assert len(deduplicate_articles(items)) == 1

def test_selector_scores_and_limits():
    a=Article('OpenAI lance un agent', 'u', 's', 'IA et LLM')
    b=Article('Météo', 'v', 's')
    assert score_article(a,['OpenAI','IA','LLM']) > score_article(b,['OpenAI','IA','LLM'])
    assert select_articles([b,a], ['OpenAI','IA','LLM'], limit=1)[0] is a

def test_cli_dry_run_ecrit_json(tmp_path):
    config={'collect': {'sources': [], 'keywords':['IA']}}
    result=run(config, dry_run=True, limit=1, output_dir=tmp_path)
    output=tmp_path/'collect.json'
    assert len(result)==1 and output.exists()
    assert json.loads(output.read_text())[0]['source']=='dry-run'
